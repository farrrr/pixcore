<?php

/**
 * Pix_Controller_NoViewException 
 * 
 * @uses Pix
 * @uses _Exception
 * @package Pix_Controller
 * @version $id$
 * @copyright 2003-2010 PIXNET
 * @author Shang-Rung Wang <srwang@pixnet.tw> 
 * @license PHP Version 3.0 {@link http://www.php.net/license/3_0.txt}
 */
class Pix_Controller_NoViewException extends Pix_Exception
{
}
