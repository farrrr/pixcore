<?php

/**
 * Pix_Controller_Dispatcher 一個網址進來，會回傳 array(controllerName, ActionName)
 * 
 * @package Pix_Controller
 * @version $id$
 * @copyright 2003-2009 PIXNET
 * @author Shang-Rung Wang <srwang@pixnet.tw> 
 * @license 
 */
class Pix_Controller_Dispatcher
{
    public function dispatch($url)
    {
	// return array($controllerName, $actionName);
    }
}
