<?php

class Pix_DbConnectErrorException extends Exception
{
}
