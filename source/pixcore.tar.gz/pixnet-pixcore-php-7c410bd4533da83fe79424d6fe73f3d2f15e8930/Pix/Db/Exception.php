<?php

/**
 * Pix_Db_Exception 
 * 
 * @uses Exception
 * @package Pix_Db
 * @copyright 2003-2010 PIXNET
 * @author Gea-Suan Lin <gslin@pixnet.tw>
 */
class Pix_Db_Exception extends Exception
{
}

