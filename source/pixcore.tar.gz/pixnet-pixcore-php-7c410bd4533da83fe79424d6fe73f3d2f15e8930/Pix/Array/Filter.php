<?php

interface Pix_Array_Filter
{
    public function filter($row, $options);
}
