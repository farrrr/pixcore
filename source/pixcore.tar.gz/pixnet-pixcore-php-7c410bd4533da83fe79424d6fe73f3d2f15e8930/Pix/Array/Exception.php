<?php

/**
 * Pix_Array_Exception 
 * 
 * @uses Pix
 * @uses _Exception
 * @package Pix_Array
 * @version $id$
 * @copyright 2003-2009 PIXNET
 * @author Shang-Rung Wang <srwang@pixnet.tw> 
 */
class Pix_Array_Exception extends Pix_Exception
{
}
