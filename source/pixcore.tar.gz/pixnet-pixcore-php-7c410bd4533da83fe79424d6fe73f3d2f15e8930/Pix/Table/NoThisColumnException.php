<?php

class Pix_Table_NoThisColumnException extends Exception
{
}
