<?php

class Pix_Table_TableNotFoundException extends Pix_Table_Exception
{
}
