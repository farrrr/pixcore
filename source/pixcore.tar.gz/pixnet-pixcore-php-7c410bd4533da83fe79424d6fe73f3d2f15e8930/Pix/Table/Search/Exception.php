<?php

/**
 * Pix_Table_Search_Exception 
 * 
 * @uses Exception
 * @package Pix_Table
 * @version $id$
 * @copyright 2003-2010 PIXNET
 * @author Shang-Rung Wang <srwang@pixnet.tw> 
 * @license PHP Version 3.0 {@link http://www.php.net/license/3_0.txt}
 */
class Pix_Table_Search_Exception extends Exception
{
}
