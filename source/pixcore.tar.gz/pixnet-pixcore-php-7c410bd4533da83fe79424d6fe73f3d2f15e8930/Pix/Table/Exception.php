<?php

/**
 * Pix_Table_Exception
 * 
 * @copyright 2003-2010 PIXNET
 */
class Pix_Table_Exception extends Exception
{
}
