<?php

/**
 * Pix_Partial_Helper 
 * 
 * @abstract
 * @package Pix_Partial
 * @version $id$
 * @copyright 2003-2010 PIXNET
 * @author Shang-Rung Wang <srwang@pixnet.tw> 
 * @license PHP Version 3.0 {@link http://www.php.net/license/3_0.txt}
 */
abstract class Pix_Partial_Helper
{
    abstract public function getFuncs();
}
