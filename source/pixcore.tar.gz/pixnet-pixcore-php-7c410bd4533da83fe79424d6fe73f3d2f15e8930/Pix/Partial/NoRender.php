<?php
/**
 * Pix_Partial_NoRender 
 * 
 * @uses Pix
 * @uses _Exception
 * @package Pix_Partial
 * @version $id$
 * @copyright 2003-2009 PIXNET
 * @author Shang-Rung Wang <srwang@pixnet.tw> 
 * @license 
 */
class Pix_Partial_NoRender extends Pix_Exception
{
}
