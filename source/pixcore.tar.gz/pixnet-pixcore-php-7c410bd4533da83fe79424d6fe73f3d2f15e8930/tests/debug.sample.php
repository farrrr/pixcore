<?php
// MYSQL 測試 DB 設定
define('PIXCORE_TEST_MYSQLHOST', 'localhost');
define('PIXCORE_TEST_MYSQLUSER', 'test');
define('PIXCORE_TEST_MYSQLPASS', '');
define('PIXCORE_TEST_MYSQLDB', 'test');
define('PIXCORE_TEST_MYSQLDB_0', 'test_0');
define('PIXCORE_TEST_MYSQLDB_1', 'test_1');

// MEMCACHE 測試設定
define('PIXCORE_TEST_MEMCACHEHOST', 'localhost');
define('PIXCORE_TEST_MEMCACHEPORT', 11211);
