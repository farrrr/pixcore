<?php

include(dirname(__FILE__) . '/../webdata/bootstrap.php');
