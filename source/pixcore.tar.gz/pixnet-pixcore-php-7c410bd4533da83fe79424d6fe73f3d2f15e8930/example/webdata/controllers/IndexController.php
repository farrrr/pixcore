<?php

class IndexController extends Pix_Controller 
{
    public function indexAction()
    {
    }
}
